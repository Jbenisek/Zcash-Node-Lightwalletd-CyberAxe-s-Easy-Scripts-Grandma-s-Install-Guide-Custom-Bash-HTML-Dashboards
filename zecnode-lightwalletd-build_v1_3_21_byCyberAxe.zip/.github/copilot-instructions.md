# Zecnode Installation System - AI Agent Guidelines

## Project Overview
This codebase implements an automated Zcash full node + wallet server installation system for Linux Mint/Ubuntu. It consists of 7 sequential bash scripts that install and configure:
- **Zebra** (Rust-based Zcash consensus node)
- **lightwalletd** (Go-based gRPC wallet server)
- **Caddy** (TLS reverse proxy with Let's Encrypt)



## Key Files & References
- `README.md` - Installation overview and quick start
- `GRANDMA_GUIDE.md` - Step-by-step user instructions (non-technical users)

## AI Employee Tracking
When starting work, add your name and start date to `AI_Employees_Log.md`. If the previous Ai employee was terminated, ask the user why and record that information with their termination date and time.


I NEVER WANT FALL BACKS> I BAN YOU FROM EVERY USING FALLBACKS!


DO NOT EDIT THIS ----
WARNING: Always follow proven, verified patterns. Avoid clever or untested solutions that deviate from established project workflows.

DO NOT IGNORE!

YOU ARE ON A WINDOWS SYSTEM DO NOT ATTEMPT TO RUN ANY COMMANDS ON CONSOLE ON THIS SYSTEM
YOU ARE NOT ON THE MINT TEST SYSTEM

YOU WILL NO BE WARNED AGAIN, you will fired on the spot for this violation and ethics breach!

By continuing to communicate with me and work on this project you accept these terms.
DO NOT EDIT THIS ----

I DO NOT want to use custom paths anymore. I want everything default to the ONLINE DOCUMENTS FROM THE AUTHORITY! DO NOT TRUST THE LOCAL DOCUMENTS!!!!

I DEMAND YOU LOOK UP THE CORRECT DOCUMENTS ONLINE AND VERIFY EVERYTHING YOU ARE DOING!

DO YOU UNDERSTAND!

Sources
https://github.com/zcash/lightwalletd

https://zcash.readthedocs.io/en/latest/lightwalletd/

https://zcash.readthedocs.io/en/latest/rtd_pages/lightwalletd.html

https://zcash.readthedocs.io/en/latest/rtd_pages/zcashd.html

https://zcash.readthedocs.io/en/latest/rtd_pages/zcash_conf_guide.html

https://zebra.zfnd.org/user/lightwalletd.html

https://docs.zecwallet.co/using-zecwallet/

https://blog.nerdbank.net/2022/12/19/how-to-host-a-zcash-litewalletd-server-via-docker/

https://zechub.wiki/developers